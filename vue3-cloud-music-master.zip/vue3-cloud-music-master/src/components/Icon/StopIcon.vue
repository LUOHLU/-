<template>
  <svg
    t="1652621776450" class="icon" viewBox="0 0 1024 1024"
    version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2355"
    width="200" height="200"
  ><path d="M209.417 62h150.008v900h-150.008v-900z" p-id="2356" /><path d="M659.417 62h149.985v900h-149.985v-900z" p-id="2357" /></svg>
</template>