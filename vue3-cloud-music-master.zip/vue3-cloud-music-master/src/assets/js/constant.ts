const LOCALE = '__LOCALE__';

export const CONSTANT = { LOCALE };