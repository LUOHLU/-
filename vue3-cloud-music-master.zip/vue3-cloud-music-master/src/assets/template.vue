<script setup lang="ts">

</script>

<template>
  <div>
    hello world
  </div>
</template>

<style scoped>

</style>
